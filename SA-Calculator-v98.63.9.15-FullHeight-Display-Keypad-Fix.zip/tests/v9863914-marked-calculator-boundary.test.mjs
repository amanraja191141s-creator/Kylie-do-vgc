import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
test('marked screenshot boundary reserves 53% for display and 47% for keypad', () => {
  const css=read('assets/css/app.css');
  assert.match(css, /#screen-viewport > #screen-calc\.active > \.calc-display\s*\{[^}]*flex:0 0 53%!important/s);
  assert.match(css, /#screen-viewport > #screen-calc\.active > \.calc-display\s*\{[^}]*height:53%!important/s);
  assert.match(css, /#screen-viewport > #screen-calc\.active > \.main-keypad\s*\{[^}]*flex:0 0 47%!important/s);
  assert.match(css, /#screen-viewport > #screen-calc\.active > \.main-keypad\s*\{[^}]*grid-template-rows:repeat\(5,minmax\(0,1fr\)\)!important/s);
});
test('all keypad keys remain inside grid cells and preserve zero span', () => {
  const html=read('index.html'), css=read('assets/css/app.css');
  const calc=html.match(/<div class="main-keypad"[\s\S]*?<\/div>/)?.[0]||'';
  assert.equal((calc.match(/class="key-btn/g)||[]).length,19);
  assert.match(css, /button\.key-btn\.zero-key\s*\{[^}]*grid-column:span 2!important/s);
  assert.match(css, /button\.key-btn\.op-key,[\s\S]*?button\.key-btn\.equal-key/);
});
test('calculator expression, preview and result elements are retained', () => {
  const html=read('index.html');
  for (const id of ['calc-display-box','calc-expr-row','calc-expr','calc-preview-row','calc-val']) assert.ok(html.includes(`id="${id}"`));
});
test('landscape layout and cache-busted Android workflow are synchronized', () => {
  const css=read('assets/css/app.css'), sw=read('service-worker.js'), wf=read('.github/workflows/main.yml'), html=read('index.html');
  assert.match(css, /@media\(max-height:500px\) and \(orientation:landscape\)/);
  assert.match(sw, /v9863915-ui103/);
  assert.match(wf, /v9863915/);
  assert.match(html, /1\.98\.64-v98\.63\.9/);
});
