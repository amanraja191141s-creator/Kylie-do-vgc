import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const cssPath = path.join(root, 'assets/css/app.css');
const css = fs.readFileSync(cssPath, 'utf8');
const build = fs.readFileSync(path.join(root, 'scripts/prepare-android-web.mjs'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
test('v98.63 hotfix layer is part of Android production CSS bundle', () => {
  assert.match(build,/assets\/css\/app\.css/);
  assert.match(html,/assets\/css\/app\.css/);
});
test('bottom dock consumes safe-area once and removes extra lower margin', () => {
  assert.match(css, /margin-bottom:0!important/);
  assert.match(css, /padding:3px 5px env\(safe-area-inset-bottom,0px\)!important/);
  assert.match(css, /#app-container>#screen-viewport/);
});
test('keypad keeps original 4x5 grid while making keys compact', () => {
  assert.match(css, /width:94%!important;height:92%!important/);
  assert.match(css, /#screen-calc\.active>\.main-keypad/);
});
test('expression and preview remain bounded and right aligned', () => {
  assert.match(css, /#calc-expr\{[^}]*text-align:right!important/);
  assert.match(css, /\.calc-preview-val\{[^}]*text-align:right!important/);
  assert.match(css, /font-variant-numeric:tabular-nums!important/);
});
test('tools and favorites have responsive grids and empty favorite state', () => {
  assert.match(css, /#screen-tools\.active \.premium-tools-grid/);
  assert.match(css, /#screen-favorites\.active \.favorites-screen-list/);
  assert.match(css, /No favorites yet/);
});
