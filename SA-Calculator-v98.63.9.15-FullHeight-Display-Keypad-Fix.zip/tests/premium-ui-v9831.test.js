const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('v98.44 replaces the old categorized drawer with the dedicated searchable premium Tools grid', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css') + read('assets/css/app.css');
  const js = read('assets/js/app.js');
  const drawer = html.slice(html.indexOf('id="sidebar-drawer"'), html.indexOf('</aside>'));
  assert.match(html, /id="screen-tools"/);
  assert.match(html, /id="premium-tools-grid"/);
  assert.match(html, /id="tools-screen-search"/);
  assert.doesNotMatch(drawer, /Quick access|drawer-category|drawer-tool-search|All tools/);
  assert.equal((html.match(/class="premium-tool-card"/g) || []).length, 17);
  assert.match(css, /grid-template-columns: repeat\(2, minmax\(0, 1fr\)\)/);
  assert.match(js, /const filterToolsScreen = \(\) =>/);
  assert.match(js, /if \(target === 'tools'\) \{ switchScreen\('tools'\); return; \}/);
});

test('every selectable currency code has a representative country or region flag mapping', () => {
  const js = read('assets/js/app.js');
  const catalogSource = js.match(/const CURRENCY_CATALOG = (\[[^;]+\]);/)[1];
  const flagsSource = js.match(/const CURRENCY_FLAG_REGIONS = (\{[\s\S]*?\});/)[1];
  const catalog = vm.runInNewContext(catalogSource);
  const flags = vm.runInNewContext(`(${flagsSource})`);
  assert.equal(catalog.length, 105);
  const missing = catalog.filter(code => !flags[code]);
  assert.equal(missing.length, 0, `missing flag mappings: ${missing.join(", ")}`);
  assert.match(js, /function currencyFlagForCode\(currencyCode\)/);
  assert.match(js, /function currencyRegionNameForCode\(currencyCode\)/);
  assert.match(js, /currency-picker-flag/);
  assert.match(js, /label\.append\(name, meta\)/);
});

test('currency picker keeps ISO code and localized name alongside the flag', () => {
  const js = read('assets/js/app.js');
  const html = read('index.html');
  assert.match(html, /id="cur-from"/);
  assert.match(html, /id="cur-to"/);
  assert.match(js, /localizedCurrencyName\(code\)/);
  assert.match(js, /currencyFlagForCode\(code\)/);
  assert.match(js, /aria-selected/);
  assert.match(js, /No matching currencies/);
});

test('standalone scientific calculator exposes the full scientific function set and independent keypad', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const sci = html.slice(html.indexOf('id="screen-scientific"'), html.indexOf('id="screen-currencies"'));
  assert.equal((sci.match(/data-sci-insert=/g) || []).length, 41);
  const functionGrid = sci.slice(sci.indexOf('class="scientific-function-grid"'), sci.indexOf('class="scientific-more-functions"'));
  assert.equal((functionGrid.match(/data-sci-insert=/g) || []).length, 18);
  for (const group of ['scientific-function-grid','scientific-keypad','scientific-memory-row','sci-angle-indicator']) assert.ok(sci.includes(group));
  assert.match(js, /function initScientific\(\)/);
  assert.match(js, /evaluateArithmetic\(sci\.expression, true, sci\.angle\)/);
  assert.doesNotMatch(html, /id="btn-sci-inline"/);
});

test('on-demand numeric keyboard is a safe-area-aware 4x4 sheet and retains editing actions', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css') + read('assets/css/app.css') + read('assets/css/app.css');
  const js = read('assets/js/app.js');
  const keypad = html.slice(html.indexOf('id="popup-keypad-sheet"'), html.indexOf('<!-- END APP CONTAINER -->'));
  for (const key of ['7','8','9','DEL','4','5','6','NEXT','1','2','3','CLR','0','00','.','DONE']) assert.match(keypad, new RegExp(`data-popup="${key}"`));
  assert.match(css, /#popup-keypad-sheet \.popup-keypad-grid \{ height:auto !important/);
  assert.match(css, /padding-bottom:env\(safe-area-inset-bottom\)/);
  assert.match(js, /function openPopupKeypad\(inputElem\)/);
  assert.match(js, /function closePopupKeypad\(\)/);
});

test('v98.32 design system preserves tool destinations and updates release identity', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const css = read('assets/css/app.css') + read('assets/css/app.css') + read('assets/css/app.css');
  const workflow = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.64-v98.63.9');
  assert.equal(manifest.version, pkg.version);
  assert.ok(html.includes(pkg.version));
  assert.ok(js.includes(`const APP_VERSION = '${pkg.version}'`));
  assert.match(css, /SA Calculator v98\.33 — unified premium interface/);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.64-v98\.63\.9'/);
  assert.match(workflow, /versionCode='1098064'/);
  for (const id of ['calc','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','settings']) assert.ok(html.includes(`id="screen-${id}"`));
});
