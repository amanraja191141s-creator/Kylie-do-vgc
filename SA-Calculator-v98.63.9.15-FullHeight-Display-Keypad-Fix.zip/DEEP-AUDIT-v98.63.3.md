# Deep source audit — v98.63.3

## Scope inspected

- Canonical application source (`index.html`, `assets/js`, `assets/css`)
- Android web bundle generated under `www/`
- Capacitor configuration and Android build preparation scripts
- Service-worker cache namespace and offline asset list
- All 360 Node regression tests
- Android GitHub Actions workflow and supplied YAML copy
- Release identity, QA and limitation documentation

## Finding fixed in this audit

The v98.63.2 archive's first full test run produced **359 passed / 1 failed**. The failing release-gate test required the exact package identity `1.98.63-v98.63` to be present in `RELEASE-VERIFICATION.md`; that identity line was missing even though it existed in the package manifest, runtime, and PWA manifest. The release verification document was corrected. The Android workflow display name was also advanced to v98.63.3 so it no longer identifies itself as v98.63.1. The actual package/runtime version remains `1.98.63-v98.63`, because this is a patch to that source line and the Android versionCode remains `1098063`.

## Validation performed after correction

- `npm test`: **360 passed / 0 failed**
- `npm run build:web`: passed; 34 required assets verified and 22 CSS layers consolidated
- `node --check`: app runtime, localization, currency localization, theme bootstrap, service worker, server, and Android preparation scripts passed
- Android workflow YAML parsed successfully and contains the `android-build` job
- Supplied YAML copy matches `.github/workflows/main.yml`
- ZIP integrity checked after packaging

## Existing v98.63.2 fixes retained

- Currency selector uses the actual ISO currency code for flag rendering
- Currency picker panel and option list can shrink/scroll with the Android keyboard
- Tool forms reserve bottom scroll clearance and retain independent keypad layout
- History cards use a title/expression/result/actions grid
- Redundant global toolbar is hidden on Tools
- Service-worker cache namespace migrated to `sa-calculator-v98-63-live-currency-dock-fix-v98635`

## Not certified in this environment

No physical Android device or emulator replay was available. This audit does not claim verified APK installation, OEM keyboard compatibility, real-time currency-provider availability, frame-rate performance, battery/memory behavior, or universal zero-bug operation. The supplied workflow builds a debug APK in GitHub Actions when run in a repository with the required Android SDK and Gradle environment.
