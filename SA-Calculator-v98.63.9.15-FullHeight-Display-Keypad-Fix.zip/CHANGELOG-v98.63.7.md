# SA Calculator v98.63.7 — UI refinement

- Home calculator display is centered, full-width on phones, and capped at 700 CSS px on wider screens.
- Home keypad buttons are reduced to 88% width / 86% height with a 42px minimum touch target (38px on very short screens).
- Currency and unit pickers show only the currently selected item when opened; typing in the search field reveals matching alternatives.
- Unit pickers now have their own search prompt and empty state.
- Existing conversion, swap, and native select change events remain the authoritative calculation path.
- Android web bundle now includes the new CSS layer and the service-worker cache key is bumped to v98637.

## Verification

Automated Node regression suite and Android web bundle generation are run for this release. A physical Android installation / visual check is not performed in this environment.
