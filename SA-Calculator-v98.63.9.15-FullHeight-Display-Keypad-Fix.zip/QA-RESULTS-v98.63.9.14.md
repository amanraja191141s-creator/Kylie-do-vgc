# QA Results — v98.63.9.14

## Change under test

- Latest Android screenshot red divider is interpreted as the display/keypad boundary.
- Calculator display is fixed to 39% of the available calculator viewport.
- Five-row keypad is fixed to the remaining 61%, with keys centered and constrained to their grid cells.
- Preserves 4-column keypad, 19 controls, wide zero key, operator/equal keys, expression editing, live preview and result mode.
- Adds compact landscape layout and refreshes service-worker cache namespace.

## Automated verification

- Full regression suite: **391 passed, 0 failed**.
- Targeted marked-boundary, converter cleanup and calculator-first tests: **7 passed, 0 failed**.
- Android web bundle generation: **passed**.
- JavaScript syntax and workflow checks are included in the GitHub Actions workflow.

## Not yet device-certified

- Physical Android installation and pixel comparison on the user's phone have not been run in this environment.
- APK build is performed by the supplied GitHub Actions workflow.
